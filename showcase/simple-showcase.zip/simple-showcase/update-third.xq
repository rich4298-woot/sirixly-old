let $doc := sdb:doc('mycol.xml', 'mydoc.xml')
return insert nodes <abstract>foobarbaz</abstract> as last into $doc/Organization/Project[@id='4711']