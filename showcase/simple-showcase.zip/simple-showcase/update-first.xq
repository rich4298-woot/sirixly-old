let $doc := sdb:doc('mycol.xml', 'mydoc.xml')
return insert nodes <a><b/></a> as first into $doc/Organization