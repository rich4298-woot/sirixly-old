let $doc := sdb:doc('mycol.xml', 'mydoc.xml')
return $doc/Organization/first::*