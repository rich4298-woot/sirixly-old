let $doc := sdb:doc('mycol.xml', 'mydoc.xml')
return insert nodes <foo><bar/>baz</foo> as first into $doc/Organization