let $doc := sdb:doc('mycol.xml', 'mydoc.xml', 3)
return $doc/Organization/Project[@id='4711']/all-time::*