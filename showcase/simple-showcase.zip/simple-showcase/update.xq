let $doc := sdb:doc('mycol.xml', 'mydoc.xml')
for $log in $doc/Organization return
( insert nodes <a><b/></a> into $log )