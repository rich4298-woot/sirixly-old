let $doc := sdb:doc('mycol.xml', 'mydoc.xml', 4)
return $doc/*