let $doc := sdb:doc('mycol.xml', 'mydoc.xml', 3)
return $doc/Organization/*